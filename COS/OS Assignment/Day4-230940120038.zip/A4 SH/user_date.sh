#!/bin/bash

echo -n "Username : "
#userName=whoami
#echo $userName
whoami
echo -n "Current date and time: "
date
echo -n "Current directory: "
pwd
