#!/bin/bash

read -p " Enter your name : " fname
read -p "Enter Your middle name : " mname
read -p "Enter your Last name : " lname

echo "Welcome Mr. $fname $mname $lname"
