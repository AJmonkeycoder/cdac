
class Sum {
public static void main(String[] ss)
 {
	 int num1=Integer.parseInt(ss[0]);
	  int num2=Integer.parseInt(ss[1]);
     System.out.print("Sum="+(num1+num2));
 }
}
