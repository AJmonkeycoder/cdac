
class HelloWorld{

	public static void main(String[] args){
		System.out.println("Hello Wolrd!");
		System.out.println("Hello " + args[0] + "!");
}

}

