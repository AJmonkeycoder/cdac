class Tank{
	private int level;
	Tank(int l){
		level=l;
	}
	public void setLevel(int level1){
		level=level1;
	}
	public int getLevel(){
		return level;
	}
}

