
public interface Stack {
 static final int stackSize=100;
 
 void push(Customer customer);
 Customer pop();
 
}
