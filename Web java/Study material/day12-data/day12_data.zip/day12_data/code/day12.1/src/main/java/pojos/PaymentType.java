package pojos;

public enum PaymentType {
	CREDIT_CARD, DEBIT_CARD, FOREX, GPAY
}
