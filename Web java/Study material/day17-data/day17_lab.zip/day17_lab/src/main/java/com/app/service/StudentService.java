package com.app.service;

import com.app.dto.StudentDTO;
import com.app.entities.Student;

public interface StudentService {
	StudentDTO addStudentDetails(StudentDTO student);
}
